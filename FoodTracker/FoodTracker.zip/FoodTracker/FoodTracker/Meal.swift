//
//  Meal.swift
//  FoodTracker
//
//  Created by framgia on 9/22/16.
//  Copyright © 2016 framgia. All rights reserved.
//

import Foundation
